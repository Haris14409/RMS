﻿function addItemToCart() {
    alert(123)
}